/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fyp;

/**
 *
 * @author HP
 */
public class Equip {
    private String eqID;
    private String eqName;
    private String freq;
    private String eqLastmain;

    public String getEqID() {
        return eqID;
    }

    public void setEqID(String eqID) {
        this.eqID = eqID;
    }

    public String getEqName() {
        return eqName;
    }

    public void setEqName(String eqName) {
        this.eqName = eqName;
    }

    public String getFreq() {
        return freq;
    }

    public void setFreq(String freq) {
        this.freq = freq;
    }

    public String getEqLastmain() {
        return eqLastmain;
    }

    public void setEqLastmain(String eqLastmain) {
        this.eqLastmain = eqLastmain;
    }
    
}
