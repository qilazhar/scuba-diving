
package com.fyp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class StaffDAO {
    
    private final Connection connection;
    private int result;
    
    public StaffDAO(){
        connection = DBConnection.getConnection();
    }
    
    public Staff retrieveOneStaff(String staffID) {
        Staff staff = new Staff();
        try {
            String query = "Select * where staffID=? ";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, staffID);
            ResultSet myRs = ps.executeQuery();
            while (myRs.next()) {
                staff.setStaffID(myRs.getString(1));
                staff.setStaffName(myRs.getString(2));
                staff.setStaffPswd(myRs.getString(3));
                staff.setStaffEmail(myRs.getString(4));
                staff.setStaffType(myRs.getString(5));
            }
        } catch (Exception e) {
            System.out.println("Exception is ;" + e);
        }
        return staff;
    }
    
}
