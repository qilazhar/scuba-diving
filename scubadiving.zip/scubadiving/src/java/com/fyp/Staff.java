/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fyp;

/**
 *
 * @author HP
 */
public class Staff {

    private String staffID;
    private String staffName;
    private String staffPswd;
    private String staffEmail;
    private String staffType;
    private int status;

   
    public String getStaffID() {
        return staffID;
    }

    public void setStaffID(String staffID) {
        this.staffID = staffID;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getStaffPswd() {
        return staffPswd;
    }

    public void setStaffPswd(String staffPswd) {
        this.staffPswd = staffPswd;
    }

    public String getStaffEmail() {
        return staffEmail;
    }

    public void setStaffEmail(String staffEmail) {
        this.staffEmail = staffEmail;
    }

    public String getStaffType() {
        return staffType;
    }

    public void setStaffType(String staffType) {
        this.staffType = staffType;
    }

    


}
