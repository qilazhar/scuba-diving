/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fyp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class EquipDAO {
    private final Connection connection;
    private int result;
    
     public EquipDAO(){
        connection = DBConnection.getConnection();
    }
    
    public Equip retrieveOneEquip(String eqID) {
        Equip equip = new Equip();
        try {
            String query = "Select * where eqID=? ";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, eqID);
            ResultSet myRs = ps.executeQuery();
            while (myRs.next()) {
                equip.setEqID(myRs.getString(1));
                equip.setEqName(myRs.getString(2));
                equip.setFreq(myRs.getString(3));
                equip.setEqLastmain(myRs.getString(4));
            }
        } catch (Exception e) {
            System.out.println("Exception is ;" + e);
        }
        return equip;
    }
    
}


